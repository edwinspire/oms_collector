using System;
using System.Text;
using System.Net;
using System.Net.NetworkInformation;
using System.ComponentModel;
using System.Threading;
using OpenMonitoringSystem; 
using System.Collections.Specialized;

namespace OpenMonitoringSystem
{

	public class Ping:Plugin
	{
		public string IP = "127.0.0.1";

		public Ping(){
			this.Name = "Ping";
			this.Table = "events_ping";
		}


		public override NameValueCollection Execute ()
		{

			NameValueCollection r = new NameValueCollection();
			r ["Status"] = "unknown";
			r ["Error"] = "-100";
			r ["IP"] = this.IP;
			
			var pingSender = new System.Net.NetworkInformation.Ping ();
			PingReply reply = pingSender.Send (this.IP, 30);
			r ["Status"] = reply.Status.ToString();

			if (IP.Length == 0) {
				r ["Error"] = "-1";
				throw new ArgumentException ("Ping needs a host or IP Address.");
			} else {
			
				r ["Status"] = reply.Status.ToString();
				if (reply.Status == IPStatus.Success)
				{

					Console.WriteLine ("IP: {0}", reply.Address.ToString ());
					Console.WriteLine ("RoundTrip time: {0} ms", reply.RoundtripTime);
					r ["Time"] = reply.RoundtripTime.ToString();
					Console.WriteLine ("Time to live: {0}", reply.Options.Ttl);
					r ["Ttl"] = reply.Options.Ttl.ToString();
					r ["Error"] = "0";
				}

				Console.WriteLine (reply.Status.ToString());
				Console.WriteLine ("Ping example completed.");

			}
			return r;
		}




	}

}

