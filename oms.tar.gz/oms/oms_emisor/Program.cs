using System;
using Mono.Data.Sqlite;
using System.Data;


namespace oms_emisor
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Console.WriteLine ("Hello World!");
			SqliteConnection m_dbConnection;

			 m_dbConnection = 	new SqliteConnection ("Data Source=oms_buffer.sqlite;Version=3;");
			m_dbConnection.Open();
			//string sql = "create table highscores (name varchar(20), score int)";
			//string sql = "CREATE TABLE highscores (name VARCHAR(20), score INT)";
			//SQLiteCommand command = new SQLiteCommand(sql, m_dbConnection);
			//command.ExecuteNonQuery();
			//string sql = "insert into highscores (name, score) values ('Me', 9001)";
			/*
string sql = "insert into highscores (name, score) values ('Me', 3000)";
SQLiteCommand command = new SQLiteCommand(sql, m_dbConnection);
command.ExecuteNonQuery();
sql = "insert into highscores (name, score) values ('Myself', 6000)";
command = new SQLiteCommand(sql, m_dbConnection);
command.ExecuteNonQuery();
sql = "insert into highscores (name, score) values ('And I', 9001)";
command = new SQLiteCommand(sql, m_dbConnection);
command.ExecuteNonQuery();
			 * */

			/*
			 * 
			 * 
string sql = "select * from highscores order by score desc";
SQLiteCommand command = new SQLiteCommand(sql, m_dbConnection);
SQLiteDataReader reader = command.ExecuteReader();

string sql = "select * from highscores order by score desc";
SQLiteCommand command = new SQLiteCommand(sql, m_dbConnection);
SQLiteDataReader reader = command.ExecuteReader();
while (reader.Read())
       Console.WriteLine("Name: " + reader["name"] + "\tScore: " + reader["score"]);



			 * 
			 * 
			 * */


		}
	}
}
