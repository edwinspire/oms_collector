using System;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace OpenMonitoringSoftware
{

	public class Configuration{

		public string Identification = "000000000000000000000000000000";
		public Int64 IdAccount = 0;
		public string ConfigFile = "appconfig.xml";
		public string HttpReceiver = "http://192.168.238.66/receiver_post_method.php";

		public Configuration(){
			//		this.Serialize();
		}

		public void Serialize(Boolean replace = false){

			if(!File.Exists(this.ConfigFile)){
				using (FileStream fs = new FileStream(this.ConfigFile, FileMode.OpenOrCreate)) {        
					XmlSerializer serializer = new XmlSerializer(this.GetType());
					serializer.Serialize(fs, this);	
				}
			}

		}

		public object Deserialize(){

			using (FileStream fs = File.OpenRead(this.ConfigFile)) {        
				XmlSerializer serializer = new XmlSerializer(this.GetType());
				return serializer.Deserialize(fs);	
			}

		}



	}

}