using System;
using System.Collections.Specialized;
using System.IO;
using System.Net;
using System.Text;
using System.Xml;
using System.Xml.Serialization;


namespace OpenMonitoringSystem
{

	public abstract class Plugin
	{ 
		protected string Name = "Ping";
		public string Table = "Ping";
		public string Receiver = "http://192.168.238.66/receiver_web.php";
		private string config_file = "";

		public abstract NameValueCollection Execute();

		public  bool Send(){

			using ( var  client =  new   WebClient ())
			{
				var  response = client.UploadValues ("http://192.168.238.66/receiver_web.php", this.Execute());

				var  responseString =  Encoding.Default.GetString(response);
				Console.WriteLine (responseString);
			}
			return true;
		}

		public void Serialize(Boolean replace = false){
			var config_name = "plugin_"+this.Name + ".config";
			if(!File.Exists(config_name)){
				using (FileStream fs = new FileStream(config_name, FileMode.OpenOrCreate)) {        
					XmlSerializer serializer = new XmlSerializer(this.GetType());
					serializer.Serialize(fs, this);	
				}
			}

		}

		public object Deserialize(){
				this.config_file = "plugin_"+this.Name + ".config"; 

			if (!File.Exists (this.config_file)) {
				Serialize ();
				using (FileStream fs = File.OpenRead(this.config_file)) {        
					XmlSerializer serializer = new XmlSerializer(this.GetType());
					return serializer.Deserialize(fs);	
				}

			} else {
			
				using (FileStream fs = File.OpenRead(this.config_file)) {        
					XmlSerializer serializer = new XmlSerializer(this.GetType());
					return serializer.Deserialize(fs);	
				}

			}

		}




	}






}

