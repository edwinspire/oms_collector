using System;
using System.IO;
using System.Text;
using  System.Collections.Specialized;
using System.Xml.Serialization;

namespace OpenMonitoringSystem
{

	public class WebRequestPostExample
	{
		public static void Main ()
		{

			var ping = new OpenMonitoringSystem.Ping ();
			ping = (Ping)ping.Deserialize ();
			ping.Send ();
			ping.Send ();
			ping.Send ();


	

	

        }
    }




}
