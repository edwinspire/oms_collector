using System;
using System.Configuration;
using OpenMonitoringSoftware;
using System.IO;
using System.Xml.Serialization;

namespace OpenMonitoringSoftware
{
	public class MainClass
	{
		public static void Main (string[] args)
		{


			/*

			Configuration o1 = new Configuration ();
			o1.Equipment = "iiiiiiHHH";
			using (FileStream fs = new FileStream("onStartEvent.exe.config", FileMode.OpenOrCreate)) {        
				XmlSerializer serializer = new XmlSerializer(typeof(Configuration));
				serializer.Serialize(fs, o1);	
			}


			Console.WriteLine ("Hello World!");

			Configuration o;
			using (FileStream fs = File.OpenRead("onStartEvent.exe.config")) {        
				XmlSerializer serializer = new XmlSerializer(typeof(Configuration));
				o = (Configuration) serializer.Deserialize(fs);	
			}
			Console.WriteLine("Deserialized object: " + o.Equipment);
			*/

			Conf2 c = new Conf2 ();
			c.ConfigFile = "configprueba.xml";
			c.Serialize ();
			c = (Conf2)c.Deserialize ();
			Console.WriteLine ("Identification = "+ c.Identification);


		}


		public class Conf2: Configuration{

			public string xxx = "tttttt";


		}



	}







}
